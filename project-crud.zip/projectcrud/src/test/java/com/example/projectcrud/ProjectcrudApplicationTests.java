package com.example.projectcrud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjectcrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
