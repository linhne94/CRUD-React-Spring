package com.example.projectcrud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectcrudApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjectcrudApplication.class, args);
	}

}
